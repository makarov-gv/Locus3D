import os
import gi
#import pygame

gi.require_version('Gst', '1.0')
gi.require_version('GstRtspServer', '1.0')
from gi.repository import Gst, GstRtspServer, GLib

Gst.init(None)

def getIP():
    # cmd = 'hostname -I | cut -d\' \' -f1'
    # ip = subprocess.check_output(cmd, shell = True) #получаем IP
    res = os.popen('hostname -I | cut -d\' \' -f1').readline().replace('\n', '')  # получаем IP, удаляем \n
    return res

class VisualisationFactory(GstRtspServer.RTSPMediaFactory):
    def __init__(self, width, height, fps, **properties):
        super(VisualisationFactory, self).__init__(**properties)
        self.fps = fps
        self.width = width
        self.height = height
        self.number_frames = 0
        self.duration = 1 / self.fps * Gst.SECOND
        self.launch_string = 'appsrc name=source is-live=true block=false format=GST_FORMAT_TIME ' \
                             'caps=video/x-raw,format=RGB,width={},height={},framerate={}/1 ' \
                             '! videoscale ! video/x-raw,width=1280,height=720 ' \
                             '! videoconvert ! video/x-raw,format=I420 ' \
                             '! x264enc speed-preset=ultrafast tune=zerolatency ' \
                             '! rtph264pay pt=96 name=pay0'.format(self.width, self.height, self.fps)
        
        #self.launch_string = "( videotestsrc is-live=true ! x264enc ! rtph264pay name=pay0 pt=96 )"
        self.buf = Gst.Buffer.new_allocate(None, self.width*self.height*3, None)

    def do_create_element(self, url):
        print(self.launch_string)
        return Gst.parse_launch(self.launch_string)

    def do_configure(self, rtsp_media):
        self.number_frames = 0
        appsrc = rtsp_media.get_element().get_child_by_name('source')
        #appsrc.set_property('block', False)
        #appsrc.set_property('is-live', True)
        #appsrc.set_property('format', 'GST_FORMAT_TIME')
        appsrc.connect('need-data', self.on_need_data)

    def on_need_data(self, src, lenght):

        '''
        self._event.wait()
        try:
            data = pygame.image.tostring(self.screen, 'RGB')  # создаем GST буффер из экрана Pygame
            #print('Получил кадр {}'.format(self.number_frames))
            
        finally:
            self._event.clear()

        buf = Gst.Buffer.new_allocate(None, len(data), None)  # Allocate memory
        buf.fill(0, data)  # Put new data in memory
'''            
        buf.duration = self.duration
        timestamp = self.number_frames * self.duration
        buf.pts = buf.dts = int(timestamp)
        buf.offset = timestamp

        
        retval = src.emit('push-buffer', self.buf)
        self.number_frames += 1
        #print(self.number_frames)
        if retval != Gst.FlowReturn.OK:
            print('Error:', retval)
        #return True

    def setBuffer(self, data):
        self.buf = Gst.Buffer.new_allocate(None, len(data), None)  # Allocate memory
        self.buf.fill(0, data)  # Put new data in memory
        
        '''    
        self.buf.duration = self.duration
        timestamp = self.number_frames * self.duration
        self.buf.pts = self.buf.dts = int(timestamp)
        self.buf.offset = timestamp
        '''
        
class GstRtspServer(GstRtspServer.RTSPServer):
    def __init__(self, width, height, fps, **properties):
        super(GstRtspServer, self).__init__(**properties)
        self.factory = VisualisationFactory(width, height, fps)
        self.factory.set_shared(True)
        self.get_mount_points().add_factory("/test", self.factory)
        self.attach(None)

        port_FrontServer = self.get_bound_port()
        print('RTSP server started: rtsp://%s:%d/test' % (getIP(), port_FrontServer))

    def setBuffer(self, data):
        self.factory.setBuffer(data)
