#!/usr/bin/env python3

import pygame
import random
import threading
import time
import requests
import json
from datetime import datetime
import time
import numpy as np

ENABLE_RTSP = True

if ENABLE_RTSP:
    from rtsp_server import *

URL = 'http://10.10.33.15:31222/user?user=all'
HTTP_REUEST_TIMEOUT = 3

WIDTH = 1920
HEIGHT = 1080
FPS = 30

POL_WIDTH = 1100
POL_HEIGHT = 1100

SPR_WIDTH = 50
SPR_HEIGHT = 50

# Задаем цвета
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
LIGHT_BLUE = (0, 191, 255)
YELLOW = (255, 255, 0)
GRAY = (100, 100, 100)
LINE_COLOR = (0, 80, 0)

class ObjType:
    """ Класс c типами объектов """
    ROBOT = 0x00
    COPTER = 0x01
    CAMERA_PTZ = 0x03
    FABRIC = 0x04
    START_ZONE = 0x05
    CHARGE_ZONE = 0x06


class ObjFunc:
    """ Класс c функциональностью объектов """
    NONE = 0x00
    TRANSPORT = 0x01
    CANNON = 0x02
    ALL = 0x03


class FabricState:
    EMPTY = 0x00
    PROD_READY = 0x01
    PROD_LOADED = 0x02


class CyberDromObject(pygame.sprite.Sprite):
    def __init__(self, fileImg, obj_id, number, objType, objFunc):
        pygame.sprite.Sprite.__init__(self)
        self.obj_id = obj_id
        self.number = number
        self.objType = objType
        self.objFunc = objFunc
        self.baseImg = pygame.image.load(fileImg)
        self.frozenImg = self.grayscale(self.baseImg)
        #self.frozenImg = pygame.image.load('img/jdoon.png')
        self.image = self.baseImg
        self.rect = self.image.get_rect()
        # self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange((WIDTH - POL_WIDTH) / 2 + 50, (WIDTH - POL_WIDTH) / 2 + POL_WIDTH - 50)
        self.rect.y = random.randrange((HEIGHT - POL_HEIGHT) / 2 + 50, (HEIGHT - POL_HEIGHT) / 2 + POL_HEIGHT - 50)
        self.speedy = random.randrange(1, 8)
        self.speedx = random.randrange(-3, 3)
        self.cannon = 10
        self.fire = False
        self.cargo = False
        self.cargoColor = BLACK
        self.height = 0
        self.lostCoord = False
        self.fabricState = FabricState.EMPTY
        self.balls = 0
        self.online = False
        self.posMetr = (0, 0, 0)
        self.yaw = 0
        self.old_yaw = 0
        self.blocked = False
        self.disqualified = False
        self.repair = False
        self.team = 0

    def update(self):
        if self.objType in (ObjType.ROBOT, ObjType.COPTER):
            
            if self.blocked:
                self.image = self.frozenImg
            else:
                self.image = self.baseImg
                
            #if (self.yaw != self.old_yaw):
            self.image = pygame.transform.rotate(self.image, self.yaw*57.32-rotateAngle*90 - 90) #радианы переводим в градусы
                
            x = self.rect.x
            y = self.rect.y
            self.rect = self.image.get_rect()
            self.rect.x = x
            self.rect.y = y
            self.old_yaw = self.yaw

            #отправляем в зону ремонта
            if self.repair:
                #print('obj: %d' % self.number)
                if self.obj_id < 4: #первая группа
                    shift = 0
                elif self.obj_id < 8: #вторая группа
                    shift = int((WIDTH - POL_WIDTH) /2) + POL_WIDTH

                self.rect.centerx = int((WIDTH - POL_WIDTH)/2 - 4*90)+10 + (self.number - 1)*90 + shift
                self.rect.centery = 1030
                

    def rotate(self, grad):
        pass

    def grayscale(self, img):
        arr = pygame.surfarray.array3d(img)
        #luminosity filter
        avgs = [[(r*0.298 + g*0.587 + b*0.114) for (r,g,b) in col] for col in arr]
        arr = np.array([[[avg,avg,avg] for avg in col] for col in avgs])
        res_img = pygame.surfarray.make_surface(arr)
        res_img.set_colorkey((0,0,0))
        return res_img

class Pepe(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.images = []
        for i in range(104):
            self.images.append(pygame.image.load('img/pepe/frame_%.3d_delay-0.02s.gif' % i))
        self.index = 0
        self.image = self.images[self.index]
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH / 2, HEIGHT / 2)

    def update(self):
        # when the update method is called, we will increment the index
        self.index += 1

        # if the index is larger than the total images
        if self.index >= len(self.images):
            # we will make the index to 0 again
            self.index = 0

        # finally we will update the image that will be displayed
        self.image = self.images[self.index]


class ScreenSaver(pygame.sprite.Sprite):
    def __init__(self, fileImg, shift=0):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(fileImg)
        self.rect = self.image.get_rect()
        self.rect.center = (WIDTH / 2, HEIGHT / 2 + shift)
        self.count = 0
        self.direction = -1

    def update(self):
        if self.count == 30:
            self.direction *= -1
            self.count = 0
        self.count += 1
        self.rect.y += self.direction

def draw_text(surf, text, size, x, y, color=WHITE, backgound=None):
    font = pygame.font.Font(font_name, size, bold=True)
    text_surface = font.render(text, True, color, backgound)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x, y)
    surf.blit(text_surface, text_rect)
    return text_rect


def convertMeterToPix(x, y):
    if rotateAngle == 0:
        x_rot = x
        y_rot = y
    elif rotateAngle == 1:
        x_rot = y
        y_rot = -x
    elif rotateAngle == 2:
        x_rot = -x
        y_rot = -y
    elif rotateAngle == 3:
        x_rot = -y
        y_rot = x
        
    pix_x = int(WIDTH/2 + x_rot * 100)
    pix_y = int(HEIGHT/2 - y_rot * 100)        
    return (pix_x, pix_y)

def AddPlayers(team, data):

    for player in data['team_info'][team]['players']:
        # print(obj, data['user'][user]['position'])
        x, y, h, yaw = data['team_info'][team]['players'][player]['current_pos']
        balls = data['team_info'][team]['players'][player]['balls']
        cannon = data['team_info'][team]['players'][player]['bullet']
        cargo = data['team_info'][team]['players'][player]['is_cargo']
        online = data['team_info'][team]['players'][player]['is_connected']
        blocked = data['team_info'][team]['players'][player]['is_blocking']
        cargoColor = data['team_info'][team]['players'][player]['color_cargo']
        fire = data['team_info'][team]['players'][player]['is_shooting']
        repair = data['team_info'][team]['players'][player]['repair']

        try:
            disqualified = data['user'][user]['server_block']
        except:
            disqualified = False

        for obj in objects:
            if obj.obj_id == int(player):
                obj.rect.center = convertMeterToPix(x, y)
                obj.yaw = yaw
                obj.cannon = cannon
                obj.cargo = cargo
                obj.balls = balls
                obj.online = online
                obj.cargoColor = cargoColor
                obj.posMetr = (x, y, h)
                obj.fire = fire
                obj.blocked = blocked
                obj.disqualified = disqualified
                obj.repair = repair
                break

if __name__ == '__main__':

    pygame.init()

    screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.FULLSCREEN)
    pygame.display.set_caption('Геоскан АРЕНА')

    # font_name = pygame.font.match_font('arial')
    font_name = pygame.font.match_font('DejaVuSans')

    clock = pygame.time.Clock()

    if ENABLE_RTSP:
        rtspServer = GstRtspServer(WIDTH, HEIGHT, 15)

        mainLoop = GLib.MainLoop()

        mainLoopThread = threading.Thread(target=mainLoop.run, daemon=True)
        mainLoopThread.start()

    all_objects = pygame.sprite.Group()

    poligonObj = pygame.sprite.Group()

    for i in range(4):
        fabric = CyberDromObject('img/vertiport.png', i, i + 1, ObjType.FABRIC, ObjFunc.NONE)
        poligonObj.add(fabric)
        all_objects.add(fabric)

    for i in range(4):
        start = CyberDromObject('img/StartBlue%d.png' % (i + 1), i + 4, i + 1, ObjType.START_ZONE, ObjFunc.NONE)
        poligonObj.add(start)
        all_objects.add(start)

    for i in range(2):
        charge = CyberDromObject('img/Charge.png', i + 8, i + 1, ObjType.CHARGE_ZONE, ObjFunc.NONE)
        poligonObj.add(charge)
        all_objects.add(charge)

    for i in range(4):
        start = CyberDromObject('img/StartRed%d.png' % (i + 1), i + 10, i + 1, ObjType.START_ZONE, ObjFunc.NONE)
        poligonObj.add(start)
        all_objects.add(start)

    objects = pygame.sprite.Group()
    #obj = CyberDromObject('img/drone_img.png', 0, 1, ObjType.COPTER, ObjFunc.ALL)
    obj = CyberDromObject('img/blue_drone.png', 0, 1, ObjType.COPTER, ObjFunc.ALL)
    objects.add(obj)
    all_objects.add(obj)

    obj = CyberDromObject('img/blue_robot.png', 1, 2, ObjType.ROBOT, ObjFunc.ALL)
    objects.add(obj)
    all_objects.add(obj)

    obj = CyberDromObject('img/blue_robot.png', 2, 3, ObjType.ROBOT, ObjFunc.ALL)
    objects.add(obj)
    all_objects.add(obj)


    obj = CyberDromObject('img/blue_drone.png', 3, 4, ObjType.COPTER, ObjFunc.ALL)
    objects.add(obj)
    all_objects.add(obj)


    obj = CyberDromObject('img/red_drone.png', 4, 1, ObjType.COPTER, ObjFunc.ALL)
    objects.add(obj)
    all_objects.add(obj)

    obj = CyberDromObject('img/red_robot.png', 5, 2, ObjType.ROBOT, ObjFunc.ALL)
    objects.add(obj)
    all_objects.add(obj)

    obj = CyberDromObject('img/red_robot.png', 6, 3, ObjType.ROBOT, ObjFunc.ALL)
    objects.add(obj)
    all_objects.add(obj)

    obj = CyberDromObject('img/red_drone.png', 7, 4, ObjType.COPTER, ObjFunc.ALL)
    objects.add(obj)
    all_objects.add(obj)

    # obj = CyberDromObject('img/camera_img.png', 9, 5, ObjType.CAMERA_PTZ, ObjFunc.NONE)
    # objects.add(obj)
    # all_objects.add(obj)

    pepe = Pepe()
    # creating a group with our sprite
    pepe_group = pygame.sprite.Group(pepe)

    # screenSaver = ScreenSaver('img/Homunculus_loxodontus.png')
    #screenSaver = ScreenSaver('img/cyber_drom_logo.png', -50)
    #screenSaver_group = pygame.sprite.Group(screenSaver)

    #img_cyberdrom = pygame.image.load('img/cyber_drom_background.png')

    img_boom = pygame.image.load('img/boom.png')
    
    ballsBLUE = 0
    ballsRED = 0

    debugMode = False
    debugFont = pygame.font.Font(font_name, 30)

    start_time = time.time()
    counter = 0

    # Цикл игры
    running = True

    rotateAngle = 0

    oldStatusGame = 0
    showTextStartTime = time.time()
    showText = ''
    showTextDelay = 0

    while running:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_d:
                    debugMode = not debugMode
                elif event.key == pygame.K_r:
                    rotateAngle += 1
                    if rotateAngle > 3:
                        rotateAngle = 0

        try:
            # objectData = requests.get(URL, timeout = HTTP_REUEST_TIMEOUT)
            objectData = requests.get(URL)

            # print(objectData.status_code)

            data = json.loads(objectData.text)
        except:
            # print ('error')
            objectData = None

        showScreenSaver = True

        if not objectData is None:
            showScreenSaver = False

            #data = json.loads(objectData.text)

            ballsBLUE = data['team_info']['Команда синих']['balls_team']
            ballsRED = data['team_info']['Команда красных']['balls_team']
            gameTime = data['server_info']['gameTime']
            statusGame = data['server_info']['state']  # статус игры 0 - простой, 1 - обратный отсчет, 2 - игра, 3 - игра закончена, 4 - игра прервана
            #maxFoul = data['max_foul']  # максимальное количество блокировок за игру

            for polygon_obj in data['polygon_info']:
                x, y, _ = data['polygon_info'][polygon_obj]['current_pos']

                objRole = data['polygon_info'][polygon_obj]['name_role']

                if objRole == 'Fabric_RolePolygon':
                    fabricColor = data['polygon_info'][polygon_obj]['role_data']['current_cargo_color']
                    fabricState = data['polygon_info'][polygon_obj]['role_data']['current_conditions']

                for obj in poligonObj:
                    if obj.obj_id == int(polygon_obj):
                        obj.rect.center = convertMeterToPix(x, y)
                        obj.fabricState = fabricState
                        obj.cargoColor = fabricColor
                        break

            AddPlayers('Команда синих', data)
            AddPlayers('Команда красных', data)

            # for player in data['team_info']['team_1']['players']:
            #     # print(obj, data['user'][user]['position'])
            #     x, y, h = data['team_info']['team_1']['players'][player]['current_pos']
            #     balls = data['team_info']['team_1']['players'][player]['balls']
            #     cannon = data['team_info']['team_1']['players'][player]['bullet']
            #     cargo = data['team_info']['team_1']['players'][player]['is_cargo']
            #     online = data['team_info']['team_1']['players'][player]['is_connected']
            #     blocked = data['team_info']['team_1']['players'][player]['is_blocking']
            #     cargoColor = data['team_info']['team_1']['players'][player]['color_cargo']
            #     fire = data['team_info']['team_1']['players'][player]['is_shooting']
            #
            #     try:
            #         disqualified = data['user'][user]['server_block']
            #     except:
            #         disqualified = False
            #
            #     for obj in objects:
            #         if obj.obj_id == int(player):
            #             obj.rect.center = convertMeterToPix(x, y)
            #             obj.cannon = cannon
            #             obj.cargo = cargo
            #             obj.balls = balls
            #             obj.online = online
            #             obj.cargoColor = cargoColor
            #             obj.posMetr = (x, y, h)
            #             obj.fire = fire
            #             obj.blocked = blocked
            #             obj.disqualified = disqualified
            #             break


        if showScreenSaver:
            # Держим цикл на правильной скорости
            #clock.tick(FPS)

            pepe_group.update()
            #screenSaver_group.update()

            # Рендеринг
            screen.fill(WHITE)
            pepe_group.draw(screen)
            draw_text(screen, 'ГЕОСКАН АРЕНА', 70, pepe.rect.centerx, pepe.rect.top - 100, BLACK)
            draw_text(screen, 'СКОРО НАЧНЕМ', 70, pepe.rect.centerx, pepe.rect.bottom + 60, BLACK)
            # zhdoon_group.draw(screen)
            # draw_text(screen, 'БОСС, СКОРО НАЧНЕМ', 70, WIDTH/2, HEIGHT - 300, BLACK)

            #screen.blit(img_cyberdrom, (0, 0))

            #screenSaver_group.draw(screen)
            # draw_text(screen, 'БОСС, СКОРО НАЧНЕМ', 70, WIDTH/2, HEIGHT - 300, BLACK)

        else:
            # Обновление координат и состояний объектов
            all_objects.update()

            # Рендеринг
            screen.fill(WHITE) #pfkbk dtcm 'rhfy ,tksv

            pygame.draw.rect(screen, GRAY,
                             ((WIDTH - POL_WIDTH) / 2, (HEIGHT - POL_HEIGHT) / 2, POL_WIDTH, POL_HEIGHT))

            # Результаты команд
            draw_text(screen, 'СИНИЕ', 50, int((WIDTH - POL_WIDTH) / 4), 20, BLUE)
            draw_text(screen, str(ballsBLUE), 70, int((WIDTH - POL_WIDTH) / 4), 80, BLACK)
            # if foulTeamPioneer > maxFoul:
            #     draw_text(screen, 'Дисквалификация', 40, int((WIDTH - POL_WIDTH) / 4), 180, BLACK)
            # else:
            #     draw_text(screen, 'Нарушения: %d из %d' % (foulTeamPioneer, maxFoul), 40,
            #               int((WIDTH - POL_WIDTH) / 4), 180, BLACK)

            draw_text(screen, 'КРАСНЫЕ', 50, int((WIDTH - POL_WIDTH) / 4 * 3) + POL_WIDTH, 20, RED)
            draw_text(screen, str(ballsRED), 70, int((WIDTH - POL_WIDTH) / 4 * 3) + POL_WIDTH, 80, BLACK)
            # if foulTeamEdubot > maxFoul:
            #     draw_text(screen, 'Дисквалификация', 40, int((WIDTH - POL_WIDTH) / 4 * 3) + POL_WIDTH, 180, BLACK)
            # else:
            #     draw_text(screen, 'Нарушения: %d из %d' % (foulTeamEdubot, maxFoul), 40,
            #               int((WIDTH - POL_WIDTH) / 4 * 3) + POL_WIDTH, 180, BLACK)

            # линии
            # вертикальные
            for x in range(0, int(POL_WIDTH/2), 100):
                pygame.draw.line(screen, LINE_COLOR, (int(WIDTH/2) + x, int(HEIGHT - POL_HEIGHT) / 2),
                                 (int(WIDTH/2) + x, int(HEIGHT - POL_HEIGHT) / 2 + POL_HEIGHT), 2)
                pygame.draw.line(screen, LINE_COLOR, (int(WIDTH/2) - x, int(HEIGHT - POL_HEIGHT) / 2),
                                 (int(WIDTH/2) - x, int(HEIGHT - POL_HEIGHT) / 2 + POL_HEIGHT), 2)
                
            # горизонтальные
            #for y in range(int((HEIGHT - POL_HEIGHT) / 2), int((HEIGHT - POL_HEIGHT) / 2 + POL_HEIGHT), 100):
            for y in range(0, int(POL_HEIGHT/2), 100):
                pygame.draw.line(screen, LINE_COLOR, (int((WIDTH - POL_WIDTH) / 2), int(HEIGHT/2)+y),
                                 (int((WIDTH - POL_WIDTH) / 2 + POL_WIDTH), int(HEIGHT/2)+y), 2)
                pygame.draw.line(screen, LINE_COLOR, (int((WIDTH - POL_WIDTH) / 2), int(HEIGHT/2)-y),
                                 (int((WIDTH - POL_WIDTH) / 2 + POL_WIDTH), int(HEIGHT/2)-y), 2)
                
            # линии ограничения зоны полетов-заездов
            #pygame.draw.line(screen, BLUE, convertMeterToPix(3, 0), convertMeterToPix(3, 11), 5)
            #pygame.draw.line(screen, RED, convertMeterToPix(7.5, 0), convertMeterToPix(7.5, 11), 5)

            # линии разделения текста по бокам
            lines = range(250, 1080, 170)
            for y in lines:
                pygame.draw.line(screen, BLUE, (10, y), ((WIDTH - POL_WIDTH) / 2 - 10, y), 5)
                pygame.draw.line(screen, RED, (10 + (WIDTH - POL_WIDTH) / 2 + POL_WIDTH, y), (WIDTH - 10, y), 5)

            draw_text(screen, 'РЕМОНТ', 40, int((WIDTH - POL_WIDTH) / 4), 950, BLACK)
            draw_text(screen, 'РЕМОНТ', 40, int((WIDTH - POL_WIDTH) / 4 * 3) + POL_WIDTH, 950, BLACK)

            # screen.blit(background, background_rect)
            all_objects.draw(screen)  # отрисовываем все спрайты

            # отрисовка текста + графика
            for obj in all_objects:

                backgroundColor = WHITE
                if obj.blocked:
                    backgroundColor = (200, 200, 200)
                if not obj.online:
                    backgroundColor = RED

                if obj.obj_id < 4: #первая группа
                    shift = 0
                elif obj.obj_id < 8: #вторая группа
                    shift = int((WIDTH - POL_WIDTH) /2) + POL_WIDTH
                    
                # наименование аппарата сверху и баллы
                if (obj.objType == ObjType.COPTER) or (obj.objType == ObjType.ROBOT):
                    name_rect = draw_text(screen, ' ИГРОК %d ' % obj.number, 50, int((WIDTH - POL_WIDTH) / 4) + 25 + shift,
                                          (100 + obj.number * 170), BLACK, backgroundColor)
                    draw_text(screen, str(obj.balls), 70, int((WIDTH - POL_WIDTH) / 4) + 20 + shift, (110 + 50 + obj.number * 170), BLACK)
                     
                    draw_text(screen, str(obj.number), 14, obj.rect.centerx, obj.rect.centery - 7, BLACK)
                    screen.blit(obj.image, (int((WIDTH - POL_WIDTH) / 4) - 160 + shift, (100 + obj.number * 170)))
                    
                    if obj.cargo:
                        draw_text(screen, ' ГРУЗ ', 30, int((WIDTH - POL_WIDTH) / 4) - 130 + shift, (180 + obj.number * 170), WHITE, obj.cargoColor)
                        #pygame.draw.rect(screen, obj.cargoColor, (int((WIDTH - POL_WIDTH) / 4) - 160 + shift - 5, (100 + obj.number * 170 - 5), 10,  10))

                    if obj.cannon > 0:
                        for i in range(0, obj.cannon):
                            screen.blit(img_boom, (int((WIDTH - POL_WIDTH) / 4) + 150 + shift, (90 + obj.number * 170 + i*55)))
                            
                if obj.disqualified:
                    pygame.draw.line(screen, RED, name_rect.topleft, name_rect.bottomright, 7)
                    pygame.draw.line(screen, RED, name_rect.topright, name_rect.bottomleft, 7)

                '''
                if obj.objFunc == ObjFunc.TRANSPORT or obj.objFunc == ObjFunc.ALL:
                    draw_text(screen, str(obj.balls), 70, int((WIDTH - POL_WIDTH) / 4) + shift, (110 + 50 + obj.number * 170), BLACK)
                elif obj.objFunc == ObjFunc.CANNON or obj.objFunc == ObjFunc.ALL:
                    draw_text(screen, 'Заряды: %d' % obj.cannon, 50, int((WIDTH - POL_WIDTH) / 4) + shift, (110 + 50 + obj.number * 170), BLACK)
                '''
                
                # подпись снизу
                if obj.objFunc == ObjFunc.TRANSPORT or obj.objFunc == ObjFunc.ALL:
                    if obj.cargo:
                        pygame.draw.rect(screen, obj.cargoColor, (
                        obj.rect.x - 5, obj.rect.y - 5, obj.rect.width + 10, obj.rect.height + 10), 2)
                        #draw_text(screen, 'Загружен', 15, obj.rect.centerx, obj.rect.bottom + 5)

                if (obj.objFunc == ObjFunc.CANNON or obj.objFunc == ObjFunc.ALL) and (not obj.repair):
                    if obj.fire:
                        pygame.draw.circle(screen, RED, obj.rect.center, 50)
                        draw_text(screen, 'БУМ', 40, obj.rect.centerx, obj.rect.centery - 20, YELLOW)
                    if obj.cannon > 0:
                        #draw_text(screen, 'Заряды %d' % obj.cannon, 15, obj.rect.centerx, obj.rect.bottom + 20)
                        pygame.draw.circle(screen, RED, obj.rect.center, 50, 2)

                # Перекрестье если заблокирован сервером, надпись OFFLINE
                if obj.objType in (ObjType.ROBOT, ObjType.COPTER, ObjType.CAMERA_PTZ):
                    if obj.disqualified:
                        pygame.draw.line(screen, RED, obj.rect.topleft, obj.rect.bottomright, 4)
                        pygame.draw.line(screen, RED, obj.rect.topright, obj.rect.bottomleft, 4)

                    if obj.online == False:
                        pygame.draw.rect(screen, GRAY, (obj.rect.centerx - 40, obj.rect.centery - 10, 80, 21))
                        draw_text(screen, 'OFFLINE', 18, obj.rect.centerx, obj.rect.centery - 9, RED)

                # Мигаем вертипортами
                if obj.objType == ObjType.FABRIC:
                    if obj.fabricState == FabricState.PROD_READY:
                        pygame.draw.rect(screen, obj.cargoColor,
                                         (obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height), 9)

                        draw_text(screen, 'Продукция готова', 15, obj.rect.centerx, obj.rect.bottom + 10)

                    elif obj.fabricState == FabricState.PROD_LOADED:
                        # мигаем
                        if int(datetime.today().timestamp() % 2):
                            pygame.draw.rect(screen, YELLOW,
                                             (obj.rect.x, obj.rect.y, obj.rect.width, obj.rect.height), 9)
                        draw_text(screen, 'Загрузка', 15, obj.rect.centerx, obj.rect.bottom+10)
                    else:
                        pygame.draw.circle(screen, RED, obj.rect.center, 70, 2)

                '''    
                if debugMode:
                    if obj.objType in (ObjType.ROBOT, ObjType.COPTER):
                        text_surface = debugFont.render('%d [%.3f %.3f %.3f]' % (obj.number, obj.posMetr[0], obj.posMetr[1], obj.posMetr[2]), True, BLACK)
                        if obj.objType == ObjType.COPTER:
                            screen.blit(text_surface, (40, (900 + obj.number*30)))
                        elif obj.objType == ObjType.ROBOT:
                            screen.blit(text_surface, (int((WIDTH-POL_WIDTH)/2) + POL_WIDTH+40, (900 + obj.number*30)))
                '''

                # статус игры 0 - простой, 1 - обратный отсчет, 2 - игра, 3 - игра закончена, 4 - игра прервана
                if statusGame == 0:
                    draw_text(screen, ' ОЖИДАЕМ ПОДКЛЮЧЕНИЯ УЧАСТНИКОВ ', 50, int(WIDTH / 2), int(HEIGHT / 2) - 25,
                              WHITE, BLACK)
                elif statusGame == 1:
                    draw_text(screen, gameTime, 200, int(WIDTH / 2), int(HEIGHT / 2) - 100, WHITE, BLACK)
                elif statusGame == 2:
                    draw_text(screen, gameTime, 80, int(WIDTH / 2), 20, WHITE)
                elif statusGame == 3:
                    draw_text(screen, ' ИГРА ОКОНЧЕНА ', 80, int(WIDTH / 2), int(HEIGHT / 2) - 40, WHITE, BLACK)
                elif statusGame == 4:
                    draw_text(screen, ' ИГРА ПРЕРВАНА ', 80, int(WIDTH / 2), int(HEIGHT / 2) - 40, WHITE, BLACK)

                if oldStatusGame != statusGame:
                    oldStatusGame = statusGame
                    if statusGame == 2:
                        showTextStartTime = time.time()
                        showText = 'СТАРТ'
                        showTextDelay = 3

                if (time.time() - showTextStartTime) < showTextDelay:  # Если время на показ текста не закончилось, то показываем
                    draw_text(screen, showText, 200, int(WIDTH / 2), int(HEIGHT / 2) - 100, RED, BLACK)

        counter += 1
        if (time.time() - start_time) > 1:  # замеряем секунду
            currentFPS = (counter / (time.time() - start_time))
            # print("FPS: %.2f" % currentFPS)
            counter = 0
            start_time = time.time()

        if debugMode:
            draw_text(screen, "FPS: %.2f" % currentFPS, 50, WIDTH / 2, 110, WHITE)
            draw_text(screen, "Rotate: %d" % int(rotateAngle*90), 20, WIDTH / 2, 160, WHITE)

        #if ENABLE_RTSP:
            #rtspServer.setBuffer(pygame.image.tostring(screen, 'RGB'))
                
        # После отрисовки всего, переворачиваем экран
        pygame.display.flip()
            
        # Держим цикл на правильной скорости
        clock.tick(FPS)            
        
    if ENABLE_RTSP:
        mainLoop.quit()  # останавливаем MainLoop
        mainLoopThread.join()  # ожидаем завершения работы потока

    pygame.quit()
    #quit()
    
